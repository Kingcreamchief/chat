/* global module */
module.exports = {
    plugins: [
        require('autoprefixer'),
    ]
}
