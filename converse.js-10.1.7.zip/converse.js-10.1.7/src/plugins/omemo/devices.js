import Device from './device.js';
import { Collection } from '@converse/skeletor/src/collection';

export default Collection.extend({ model: Device });
